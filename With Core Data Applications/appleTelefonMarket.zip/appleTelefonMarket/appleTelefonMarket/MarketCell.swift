//
//  MarketCell.swift
//  appleTelefonMarket
//
//  Created by Reza Dysta SATRIA on 1.06.2023.
//

import UIKit

class MarketCell : UITableViewCell{

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var descLabel: UILabel!
    
    @IBOutlet weak var colorLabel: UILabel!
}
